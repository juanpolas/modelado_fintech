# MiroFish Argentina Fintech Behavior Simulation Platform

## Project Overview
This repository adapts the open-source [MiroFish](https://github.com/666ghj/MiroFish) into a web-based fintech behavior simulation platform focused on Argentina. It simulates synthetic user behavior under product, macro, company, and future-scenario conditions.

## How MiroFish Was Adapted
### How MiroFish works today (base repo)
- Backend was Flask-first, built around multi-agent social simulation workflows (graph building, environment setup, simulation, reporting).
- Frontend was a Vue app for the original multi-step simulation flow.
- LLM integration existed for simulation/report tasks with OpenAI-compatible APIs.
- Persistence existed for project/simulation artifacts in upload folders.

### Reused
- Monorepo structure (`backend`, `frontend`, root scripts).
- Vue + Vite frontend stack.
- OpenAI-compatible LLM access pattern, now generalized by provider vars.

### Modified
- Backend adapted to a Flask MVP service (base repo already Flask) for fintech simulation APIs.
- Frontend replaced with a pragmatic dashboard flow: gate + simulation + managers + runs + settings.
- Config and start scripts updated for local and RunPod Pod workflows.

### Added
- Access-code gate using cookie session (`APP_ACCESS_CODE`).
- Dynamic archetype/scenario CRUD with SQLite persistence.
- Argentina-specific simulation engine and default archetypes/scenarios.
- Future scenario translator, global impact translator, tactical strategy advisor, disruptive innovation advisor.
- Run persistence, duplication, export-ready JSON.
- Tests for simulation/parsing/fallback.

## Architecture
- `backend`: Flask + SQLite + simulation engine + LLM abstraction.
- `frontend`: Vue SPA with required pages and charts.
- `data`: SQLite DB (`fintech_sim.db`) and runtime artifacts.
- `scripts`: local/RunPod setup and startup helpers.
- `docker`: optional container flow.

## Key Features
- Public URL access gate with shared code and logout.
- Dynamic archetype management (CRUD, duplicate, import/export JSON).
- Dynamic scenario management (CRUD, duplicate, import/export JSON).
- Country + company context editing per simulation.
- Future scenario and global-event impact translation into structured qualitative variables.
- Multi-step simulation with synthetic Argentine fintech user agents.
- Tactical recommendations and disruptive innovation ideas.
- Past runs, run duplication, run export.
- DeepSeek/Qwen/mock provider switching through env vars.

## Local Development Setup
```bash
git clone https://github.com/666ghj/MiroFish.git
cd MiroFish
cp .env.example .env
# set APP_ACCESS_CODE in .env

make setup
make dev
```

Default URLs:
- Frontend: `http://localhost:5173`
- Backend: `http://localhost:8000`

## Environment Variables
```env
APP_ACCESS_CODE=change-me
SESSION_SECRET=replace-with-long-random-secret
LLM_PROVIDER=mock
LLM_BASE_URL=
LLM_API_KEY=
LLM_MODEL=qwen-plus
BACKEND_HOST=0.0.0.0
BACKEND_PORT=8000
FRONTEND_PORT=5173
FRONTEND_ORIGIN=http://localhost:5173
DATABASE_PATH=./data/fintech_sim.db
```

## Configuring DeepSeek
```env
LLM_PROVIDER=deepseek
LLM_BASE_URL=https://api.deepseek.com/v1
LLM_API_KEY=your_key
LLM_MODEL=deepseek-chat
```

## Configuring Qwen
```env
LLM_PROVIDER=qwen
LLM_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
LLM_API_KEY=your_key
LLM_MODEL=qwen-plus
```

## Running In Mock Mode
```env
LLM_PROVIDER=mock
```
No external API calls are needed; deterministic fallback remains active.

## API Reference
- `GET /health`
- `POST /simulate`
- `GET /scenarios`
- `POST /scenarios`
- `PUT /scenarios/{id}`
- `DELETE /scenarios/{id}`
- `GET /archetypes`
- `POST /archetypes`
- `PUT /archetypes/{id}`
- `DELETE /archetypes/{id}`
- `GET /runs`
- `GET /runs/{id}`
- `POST /runs/{id}/duplicate`
- `POST /translate-scenario`
- `POST /impact-translate`
- `POST /strategy-recommend`
- `POST /innovation-recommend`

Support endpoints:
- `POST /auth/login`
- `POST /auth/logout`
- `GET /auth/status`
- `GET /settings`
- `PUT /settings`

## Sample curl Commands
```bash
curl -X POST http://localhost:8000/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"code":"change-me"}' \
  -c cookies.txt

curl http://localhost:8000/archetypes -b cookies.txt

curl -X POST http://localhost:8000/translate-scenario \
  -H 'Content-Type: application/json' -b cookies.txt \
  -d '{"text":"Cambio de gobierno con incertidumbre"}'

curl -X POST http://localhost:8000/impact-translate \
  -H 'Content-Type: application/json' -b cookies.txt \
  -d '{"text":"There is a war in the Middle East"}'
```

## Running A Sample Simulation
1. Login from web UI with `APP_ACCESS_CODE`.
2. Go to `New Simulation`.
3. Select scenario/archetype mix, edit country+company context.
4. Optionally apply AI translation and edit generated fields.
5. Click `Run Simulation`.

## Using The Archetype Manager
- Open `Archetype Manager`.
- Create/edit/delete/duplicate archetypes.
- Import/export archetypes as JSON.
- Edit `behavioral_prompt_template` per archetype.

## Using The Scenario Manager
- Open `Scenario Manager`.
- Create/edit/delete/duplicate scenarios.
- Import/export scenarios as JSON.

## Using Scenario Translation
- Enter future scenario text in `New Simulation`.
- Click `Translate Scenario`.
- Review/edit structured output before running.

## Using Impact Translation
- Enter global event text in `New Simulation`.
- Click `Translate Global Event Impact`.
- Review/edit structured local impact variables before running.

## Using Tactical Recommendations
- Generated automatically after simulation.
- Also available via `POST /strategy-recommend`.

## Using Disruptive Innovation Ideas
- Generated automatically after simulation under `Innovation Lab`.
- Also available via `POST /innovation-recommend`.

## Viewing Results
Results panel includes:
- Executive metric cards
- Timeline chart lines (churn, trust deterioration, liquidity stress)
- Final action distribution
- Archetype-level breakdown in output payload
- Tactical recommendations
- Disruptive recommendations
- Duplicate/export run actions

## Deploy On RunPod
### Fresh Pod commands (copy-paste)
```bash
sudo apt update
sudo apt install -y git

git clone https://github.com/666ghj/MiroFish.git
cd MiroFish
cp .env.example .env
# edit .env (set APP_ACCESS_CODE, optional LLM vars)

./scripts/runpod_setup.sh
```

### Start services with tmux
```bash
./scripts/start_all.sh
tmux attach -t mirofish-fintech
```

### Manual start
```bash
./scripts/start_backend.sh
# in another shell
./scripts/start_frontend.sh
```

### nohup alternative
```bash
nohup ./scripts/start_backend.sh > backend.log 2>&1 &
nohup ./scripts/start_frontend.sh > frontend.log 2>&1 &
```

RunPod notes:
- Bind host is `0.0.0.0`.
- Use Pod public TCP/HTTP mapping for `FRONTEND_PORT` and optionally `BACKEND_PORT`.
- Keep backend private if possible and expose frontend publicly.

## Security / Data Safety Notes
- Use only synthetic users and synthetic scenario variables.
- Do not upload PII or customer-level data.
- Do not send customer-level sensitive data to external LLM APIs.
- Access gate is MVP auth for demo/internal usage, not enterprise IAM.

## Cost Notes
Approximate per simulation (LLM-enabled):
- Agent reasoning calls are sampled, not full-agent every step.
- Typical run (`300 agents`, `12 steps`, `1 MC`) with sampled LLM usage: usually low single-digit cents to low tens of cents depending on model/provider.
- Translation and recommendation endpoints add small extra cost (typically far less than full simulation reasoning).
- `mock` mode has zero LLM token cost.

## Tests
Run:
```bash
make test
```
Covers:
- simulation logic
- seeded archetype/scenario loading
- scenario translation parsing
- impact translation parsing
- tactical recommendation parsing
- disruptive recommendation parsing
- fallback behavior in mock mode
