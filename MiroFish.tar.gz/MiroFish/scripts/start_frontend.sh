#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR/frontend"

npm install
exec npm run dev -- --host 0.0.0.0 --port "${FRONTEND_PORT:-5173}"
