#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[1/6] System dependencies"
sudo apt update
sudo apt install -y python3 python3-venv python3-pip git curl tmux

if ! command -v node >/dev/null 2>&1; then
  echo "[2/6] Installing Node.js 20"
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt install -y nodejs
fi

echo "[3/6] Python dependencies"
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r backend/requirements.txt

echo "[4/6] Frontend dependencies"
cd frontend
npm install
npm run build
cd "$ROOT_DIR"

echo "[5/6] Environment"
if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created .env from .env.example"
fi

echo "[6/6] Next steps"
echo "- Edit .env and set APP_ACCESS_CODE"
echo "- Start services: ./scripts/start_all.sh"
echo "- Or manually: ./scripts/start_backend.sh and ./scripts/start_frontend.sh"
